GALLERY PHOTOS
==============
Is zip mein sirf aapka logo (logo.png) hai.
Apni gallery ki photos is 'assets' folder mein daal dijiye,
in exact naamon ke saath (jaise pehle the):

1912.jpg
1643.jpg
1639.jpg
1633.jpg
1628.jpg
1636.jpg
1590.jpg
1388.png

Ya phir index.html mein gallery section ke <img src="assets/xxxx.jpg">
lines ko apne naye photo filenames se replace kar dein.
